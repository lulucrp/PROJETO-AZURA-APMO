import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../../constants/Colors';

export default function GuessLogItem({ item, index }) {
  const isHigher = item.direction === 'higher';
  return (
    <View style={styles.row}>
      <View style={styles.number}><Text style={styles.numberText}>{item.value}</Text></View>
      <View style={styles.info}>
        <Text style={styles.title}>Palpite {index + 1}</Text>
        <Text style={styles.hint}>{isHigher ? 'o número secreto é maior' : 'o número secreto é menor'}</Text>
      </View>
      <Ionicons
        name={isHigher ? 'arrow-up' : 'arrow-down'}
        size={20}
        color={COLORS.azure}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.paleBlue,
    borderRadius: 14, padding: 10, marginBottom: 7,
  },
  number: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.white,
    alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.blue,
  },
  numberText: { color: COLORS.azure, fontWeight: '800' },
  info: { flex: 1, marginLeft: 10 },
  title: { color: COLORS.text, fontWeight: '800', fontSize: 12 },
  hint: { color: COLORS.textSoft, fontSize: 11, marginTop: 2 },
});
