import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../../constants/Colors';

export default function PrimaryButton({ title, icon, onPress, style, textStyle }) {
  return (
    <View style={[styles.shadow, style]}>
      <Pressable
        onPress={onPress}
        android_ripple={{ color: COLORS.ripple }}
        style={({ pressed }) => [styles.button, pressed && styles.pressed]}
      >
        {icon ? <Ionicons name={icon} size={18} color={textStyle?.color || COLORS.white} /> : null}
        <Text style={[styles.text, textStyle]}>{title}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  shadow: {
    borderRadius: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  button: {
    minHeight: 48,
    paddingHorizontal: 14,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: COLORS.azure,
    backgroundColor: COLORS.azure,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 7,
    overflow: 'hidden',
  },
  pressed: { opacity: 0.72 },
  text: { color: COLORS.white, fontWeight: '800', fontSize: 14 },
});
