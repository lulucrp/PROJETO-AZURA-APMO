export const COLORS = {
  background: '#F5FAFF',
  blush: '#E5F3FF',
  paleBlue: '#EDF8FF',
  blue: '#A7D7F7',
  azure: '#4B9FEA',
  deepAzure: '#2469A8',
  text: '#294052',
  textSoft: '#6D8291',
  muted: '#9DAFBC',
  white: '#FFFFFF',
  gold: '#E5A94A',
  ripple: '#B9DDF7'
};
