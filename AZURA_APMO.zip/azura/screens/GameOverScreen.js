import React from 'react';
import { FlatList, ImageBackground, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import PrimaryButton from '../components/game/PrimaryButton';
import GuessLogItem from '../components/game/GuessLogItem';
import Card from '../components/ui/Card';
import Title from '../components/ui/Title';
import { COLORS } from '../constants/Colors';

function getStars(rounds) {
  if (rounds <= 4) return 3;
  if (rounds <= 7) return 2;
  return 1;
}

export default function GameOverScreen({ secretNumber, difficulty, history, record, onNewGame }) {
  const rounds = history.length + 1;
  const stars = getStars(rounds);

  return (
    <LinearGradient colors={[COLORS.blush, COLORS.background, '#FFFFFF']} style={styles.root}>
      <ImageBackground
        source={require('../assets/azura-pattern.png')}
        resizeMode="cover"
        imageStyle={styles.pattern}
        style={styles.background}
      >
        <View style={styles.content}>
          <View style={styles.trophy}>
            <Ionicons name="sparkles" size={34} color={COLORS.azure} />
          </View>
          <Title>Leitura concluída!</Title>
          <Text style={styles.subtitle}>o AZURA encontrou sua resposta ✦</Text>

          <Card style={styles.summary}>
            <Text style={styles.stars}>{'★'.repeat(stars)}{'☆'.repeat(3 - stars)}</Text>
            <Text style={styles.result}>O número era <Text style={styles.bold}>{secretNumber}</Text></Text>
            <Text style={styles.result}>em <Text style={styles.bold}>{rounds}</Text> palpites</Text>
            {record && <Text style={styles.record}>Recorde da sessão: {record}</Text>}
          </Card>

          <Text style={styles.historyTitle}>Histórico da leitura</Text>
          <View style={styles.listBox}>
            <FlatList
              data={history}
              renderItem={({ item, index }) => <GuessLogItem item={item} index={index} />}
              keyExtractor={(item, index) => `${item.value}-${index}`}
              contentContainerStyle={{ padding: 10 }}
            />
          </View>

          <PrimaryButton title="Nova leitura" icon="refresh" onPress={onNewGame} />
        </View>
      </ImageBackground>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  background: { flex: 1 },
  pattern: { opacity: 0.12 },
  content: { flex: 1, padding: 22, alignItems: 'stretch' },
  trophy: { alignSelf: 'center', width: 72, height: 72, borderRadius: 36, backgroundColor: COLORS.white, alignItems: 'center', justifyContent: 'center', elevation: 4, marginTop: 10 },
  subtitle: { textAlign: 'center', color: COLORS.textSoft, marginBottom: 16 },
  summary: { alignItems: 'center', padding: 18, marginBottom: 14 },
  stars: { color: COLORS.gold, fontSize: 28, letterSpacing: 5, marginBottom: 6 },
  result: { color: COLORS.text, fontSize: 17, lineHeight: 27 },
  bold: { color: COLORS.azure, fontWeight: '800' },
  record: { color: COLORS.textSoft, fontSize: 12, marginTop: 8 },
  historyTitle: { color: COLORS.text, fontWeight: '800', marginBottom: 8 },
  listBox: { flex: 1, backgroundColor: COLORS.white, borderRadius: 18, borderWidth: 1, borderColor: COLORS.blue, marginBottom: 14, overflow: 'hidden' }
});
