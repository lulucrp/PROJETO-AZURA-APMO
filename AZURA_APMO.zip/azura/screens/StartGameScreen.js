import React, { useState } from 'react';
import { Alert, ImageBackground, StyleSheet, Text, TextInput, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import PrimaryButton from '../components/game/PrimaryButton';
import Title from '../components/ui/Title';
import Card from '../components/ui/Card';
import { COLORS } from '../constants/Colors';

const MODES = [
  { id: 'easy', label: 'Fácil', range: '1–50', min: 1, max: 50, icon: 'sparkles-outline' },
  { id: 'normal', label: 'Clássico', range: '1–99', min: 1, max: 99, icon: 'heart-outline' },
  { id: 'hard', label: 'Insano', range: '1–200', min: 1, max: 200, icon: 'flame-outline' }
];

export default function StartGameScreen({ onStartGame, record }) {
  const [value, setValue] = useState('');
  const [mode, setMode] = useState(MODES[1]);

  const confirm = () => {
    const parsed = parseInt(value, 10);
    if (isNaN(parsed) || parsed <= 0 || parsed > mode.max) {
      Alert.alert('Profundidade inválida', `Digite um número entre ${mode.min} e ${mode.max}.`, [
        { text: 'Entendi', onPress: () => setValue('') }
      ]);
      return;
    }
    onStartGame(parsed, mode);
  };

  return (
    <LinearGradient colors={[COLORS.blush, COLORS.background, '#FFFFFF']} style={styles.root}>
      <ImageBackground
        source={require('../assets/azura-pattern.png')}
        resizeMode="cover"
        imageStyle={styles.pattern}
        style={styles.background}
      >
        <View style={styles.content}>
          <View style={styles.logo}>
            <Ionicons name="sparkles" size={25} color={COLORS.azure} />
          </View>
          <Title>AZURA</Title>
          <Text style={styles.subtitle}>o oráculo tenta ler sua mente ✦</Text>

          <Card style={styles.mainCard}>
            <Text style={styles.label}>Escolha a profundidade secreta</Text>
            <Text style={styles.hint}>O oráculo vai tentar encontrar seu número.</Text>
            <TextInput
              style={styles.input}
              value={value}
              onChangeText={setValue}
              keyboardType="number-pad"
              maxLength={3}
              placeholder={`${mode.min}–${mode.max}`}
              placeholderTextColor={COLORS.muted}
            />

            <Text style={styles.label}>Nível</Text>
            <View style={styles.modes}>
              {MODES.map(item => (
                <View key={item.id} style={styles.modeWrap}>
                  <PrimaryButton
                    title={item.label}
                    icon={item.icon}
                    onPress={() => setMode(item)}
                    style={mode.id === item.id ? styles.selected : styles.unselected}
                    textStyle={mode.id === item.id ? styles.selectedText : styles.unselectedText}
                  />
                  <Text style={styles.range}>{item.range}</Text>
                </View>
              ))}
            </View>

            <PrimaryButton title="Começar leitura" icon="arrow-forward" onPress={confirm} />
          </Card>

          <View style={styles.record}>
            <Ionicons name="trophy-outline" size={18} color={COLORS.azure} />
            <Text style={styles.recordText}>
              {record ? `Recorde da sessão: ${record} palpites` : 'Seu recorde aparecerá aqui'}
            </Text>
          </View>
        </View>
      </ImageBackground>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  background: { flex: 1 },
  pattern: { opacity: 0.15 },
  content: { flex: 1, padding: 24, justifyContent: 'center' },
  logo: {
    alignSelf: 'center', width: 54, height: 54, borderRadius: 27,
    backgroundColor: COLORS.white, alignItems: 'center', justifyContent: 'center',
    elevation: 4, shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }
  },
  subtitle: { textAlign: 'center', color: COLORS.textSoft, marginBottom: 24, fontSize: 15 },
  mainCard: { padding: 20 },
  label: { color: COLORS.text, fontWeight: '700', marginTop: 4, marginBottom: 6, fontSize: 14 },
  hint: { color: COLORS.textSoft, fontSize: 13, marginBottom: 12 },
  input: {
    height: 58, borderWidth: 1.5, borderColor: COLORS.blue,
    backgroundColor: COLORS.white, borderRadius: 16, paddingHorizontal: 18,
    fontSize: 24, fontWeight: '700', color: COLORS.azure, textAlign: 'center', marginBottom: 16
  },
  modes: { flexDirection: 'row', gap: 8, marginBottom: 18 },
  modeWrap: { flex: 1, alignItems: 'center' },
  selected: { backgroundColor: COLORS.azure, borderColor: COLORS.azure, paddingHorizontal: 6 },
  unselected: { backgroundColor: COLORS.white, borderColor: COLORS.blue, paddingHorizontal: 6 },
  selectedText: { color: COLORS.white, fontSize: 12 },
  unselectedText: { color: COLORS.azure, fontSize: 12 },
  range: { fontSize: 11, color: COLORS.muted, marginTop: 4 },
  record: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 18, gap: 7 },
  recordText: { color: COLORS.textSoft, fontSize: 13 }
});
